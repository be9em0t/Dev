#from Tkinter import *
import Tkinter

root = Tkinter.Tk()
#root.withdraw() #use to hide tkinter window
root.title("TT AutoExport")
root.geometry("500x400")


m1 = Tkinter.PanedWindow()

m1.pack(fill=Tkinter.BOTH, expand=1)

left = Tkinter.Label(m1, text="left pane")
m1.add(left)

m2 = Tkinter.PanedWindow(m1, orient=Tkinter.VERTICAL)
m1.add(m2)

top = Tkinter.Label(m2, text="top pane")
m2.add(top)

bottom = Tkinter.Label(m2, text="bottom pane")
m2.add(bottom)

Tkinter.mainloop()