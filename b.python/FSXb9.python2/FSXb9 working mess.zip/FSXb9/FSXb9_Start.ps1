cd c:\Work\OneDrive\Dev\b.python\FSXb9\FSXb9
su c:\Ketarin\Data\Python2\pythonw.exe c:\Work\OneDrive\Dev\b.python\FSXb9\FSXb9\FSXb9Admin.pyw