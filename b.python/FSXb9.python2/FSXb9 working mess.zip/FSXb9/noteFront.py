import win32gui, win32con
 
def windowEnumerationHandler(hwnd, top_windows):
    top_windows.append((hwnd, win32gui.GetWindowText(hwnd)))
 
if __name__ == "__main__":
    results = []
    top_windows = []
    win32gui.EnumWindows(windowEnumerationHandler, top_windows)
    for i in top_windows:
        if "microsoft flight simulator x with wideserver" in i[1].lower():
            print i
            win32gui.ShowWindow(i[0],win32con.SW_RESTORE)
            win32gui.SetForegroundWindow(i[0])
            # win32gui.BringWindowToTop(i[0])
            # win32gui.SetActiveWindow(i[0])
            # win32gui.ShowWindow(i[0],5)
            break